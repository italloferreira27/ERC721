## Ambiente Virtual em Python 

`sudo apt install python3-virtualenv` - Instala o pacote python3-virtualenv
`virtualenv env` - Cria um novo ambiente virtual Python "env"
`source env/bin/activate` - Ativa o ambiente virtual
`pip freeze` - Lista as bibliotecas python instaladas
- [Reference](https://towardsdatascience.com/create-virtual-environment-using-virtualenv-and-add-it-to-jupyter-notebook-6e1bf4e03415)

<!-- `pip install python-dotenv` - Carregar variáveis de ambiente de um arquivo "env" -->
